open Vector2d

(* Created objects, removed objects, (current, last) obects *)
type 'a objlist = 'a list * 'a list * ('a * 'a) list

type gamestate = {
   (* Game meta-data *)
   frames : int;
   lastCalc : int;
   continue : bool;

   (* Game resources *)
   input : gamestate Input.inputContext;
   res : Resources.resourcePool;

   (* Graphical stuff *)
   zoom : float;
   loc : vector2D;

   (* Game objects *)
   rocks : Objs.rock list;
   oldRocks : Objs.rock list;
   level : Level.level;

   player : Player.player;
   oldPlayer : Player.player;

   shots : Weapon.shot list;
   oldShots : Weapon.shot list;
}

let initInput res =
   let ic = Input.createContext () in
   let ic = Input.bindQuit ic (fun g -> {g with continue = false}) in
   let ic = Input.bindMany Input.bindButtonPress ic
      [(Sdlkey.KEY_q, (fun _ g -> {g with continue = false}));
      (Sdlkey.KEY_ESCAPE, (fun _ g -> {g with continue = false}))]
   in
   let ic = Input.bindMany Input.bindButtonHold ic
      [(Sdlkey.KEY_LEFT, (fun g -> {g with player = g.player#rotateLeft}));
      (Sdlkey.KEY_RIGHT, (fun g -> {g with player = g.player#rotateRight}));
      (Sdlkey.KEY_UP, (fun g -> {g with player = g.player#thrust}));
      (Sdlkey.KEY_c, (fun g -> let p, shots = g.player#fire in
      {g with player = p; shots = shots @ g.shots}));
      ]
   in
   ic

let initGamestate ic res = { 
   frames = 0;
   lastCalc = 0;
   continue = true;

   input = ic; 
   res = res; 

   loc = (0.,0.); 
   zoom = 1.;

   (*
   features = [new Objs.rock (0.0, 0.0) (0.01, 0.01); 
   new Objs.spirally (0.0,0.0)];
   *)
   rocks = Objs.bunchOf 100 Objs.randomRock;
   oldRocks = [];
   level = {Level.background = Level.basicLevelDraw};

   player = new Player.player;
   oldPlayer = new Player.player;

   shots = [];
   oldShots = [];
}


let getScreenBounds g loc =
    let x, y = loc in 
   (* 4:3 aspect ratio *)
   let x1 = x +. (1.25 *. g.zoom)
   and x2 = x -. (1.25 *. g.zoom)
   and y1 = y +. g.zoom
   and y2 = y -. g.zoom in
   (x2,x1,y1,y2)

let setView g loc =
   let x1, x2, y1, y2 = getScreenBounds g loc in
   Drawing.setView x1 x2 y1 y2



let doDrawing now g =
   let dt = now - g.lastCalc in
   (* ...oops.  What do we do when a feature gets added or removed?! *)
   let rockScene = 
      List.concat (List.map2 
      (fun cur prev -> cur#draw (prev:>Objs.gameobj) dt) g.rocks g.oldRocks)
   and playerScene = g.player#draw g.oldPlayer dt
   and shotScene = 
      List.concat (List.map2 
      (fun cur prev -> cur#draw (prev:>Objs.gameobj) dt) g.shots g.oldShots)
   and levelScene = g.level.Level.background () 
   in

   let finalScene = Drawing.mergeScene rockScene levelScene in
   let finalScene = Drawing.mergeScene playerScene finalScene in
   let finalScene = Drawing.mergeScene shotScene finalScene in
   Drawing.drawScene finalScene;
   setView g (g.player#lerpLoc g.oldPlayer dt);
;;


let doCalc now g =
   if (now - g.lastCalc) >= Globals.calcInterval then
      let ic, g = Input.doInput g.input g in
      let newRocks = List.map (fun f -> f#calc) g.rocks in
      let newShots = List.map (fun f -> f#calc) g.shots in
      let newPlayer = g.player#calc in
      (* This GC is harmonious and auspicious.  It makes the game
       * run slightly faster.
       *)
      Gc.minor ();
      {g with 
      rocks = newRocks;
      oldRocks = g.rocks; 
      player = newPlayer;
      oldPlayer = g.player;
      shots = newShots;
      oldShots = g.shots;

      input = ic; 
      lastCalc = now; 
   }
   else
      g




let rec doMainLoop g =
   let now = Sdltimer.get_ticks () in
   if g.continue then begin
      let g = {g with frames = g.frames + 1} in
      (*let g = doInput g in *)
      let g = doCalc now g in
      doDrawing now g;
      doMainLoop g;
      (* Uncommenting the following currently makes it hang and hang and 
       * hang upon trying to quit.
       * I'm... kinda scared, actually.
       *)
      (*Sdltimer.delay 20;  *)
   end
   else begin
      let frames = float_of_int g.frames
      and now = (float_of_int now) /. 1000. in
      Printf.printf "FPS: %f\n" (frames /. now);
   end



let main () =
   let res = Resources.createResourcePool () in

   let mainConf = Resources.getConfig res "cfg/main.cfg" in
   let x = Cfg.getInt mainConf "screen.x"
   and y = Cfg.getInt mainConf "screen.y" in
   Util.init x y;
   
   let ic = initInput res in 
   let g = initGamestate ic res in

   Gc.set { (Gc.get ()) with Gc.minor_heap_size = 0x100000};

   doMainLoop g; 

   Util.quit ()

let _ = main ()
